﻿namespace EasySave.NS_Model
{
    public enum BackupType
    {
        FULL,
        DIFFRENTIAL
    }
}
