﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EasySave.NS_Model
{
    public class ReceiveObject
    {
        public string action { get; set; }
        public int[] selectedId { get; set; }
    }
}
