﻿using System;
using System.IO;
using System.Collections;

namespace CryptoSoft
{
    class Program
    {
        static int Main(string[] args)
        {
            Console.WriteLine("Please enter the source directory path:");
            string srcDir = Console.ReadLine();
            Console.WriteLine("Please enter the destination directory path:");
            string dstDir = Console.ReadLine();

            if (string.IsNullOrEmpty(srcDir) || string.IsNullOrEmpty(dstDir))
            {
                Console.WriteLine("Missing arguments.");
                return -1;
            }
            else if (!Directory.Exists(srcDir))
            {
                Console.WriteLine("Source directory doesn't exist.");
                return -1;
            }

            try
            {
                // Ensure destination directory exists
                Directory.CreateDirectory(dstDir);

                DateTime startTime = DateTime.Now;

                // Encryption key
                byte[] byteKey = new byte[8] { 12, 255, 102, 147, 8, 52, 157, 235 };
                BitArray bitKey = new BitArray(byteKey);

                // Process each file in the source directory
                foreach (string srcFilePath in Directory.GetFiles(srcDir))
                {
                    string fileName = Path.GetFileName(srcFilePath);
                    string dstFilePath = Path.Combine(dstDir, fileName);

                    // Read and encrypt the file
                    byte[] byteToEncrypt = File.ReadAllBytes(srcFilePath);
                    BitArray bitToEncrypt = new BitArray(byteToEncrypt);

                    byte[] byteCrypted = new byte[byteToEncrypt.Length];
                    BitArray bitCrypted = new BitArray(bitToEncrypt.Length);

                    for (int i = 0; i < bitToEncrypt.Length; i++)
                    {
                        int j = i % byteKey.Length;
                        bitCrypted[i] = bitToEncrypt[i] ^ bitKey[j];
                    }

                    bitCrypted.CopyTo(byteCrypted, 0);

                    // Write the encrypted file to the destination directory
                    File.WriteAllBytes(dstFilePath, byteCrypted);
                }

                TimeSpan duration = DateTime.Now - startTime;
                Console.WriteLine($"All files encrypted successfully in {duration.TotalSeconds} seconds.");
                return 0; // Success
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
                return -1; // Failure
            }
        }
    }
}
